//
// Created by Nhan Nguyen on 01/03/2021.
//
#ifndef MONGOL_H
#define MONGOL_H

// The library here is concretely set, students are not allowed to include any other libraries.

string readyForBattle(const string ID[], const int NID, const string input1[], const int N1);
int decode(const string A, const string B);
string findRoute(const string input3);
string decodeVfunction(const string A, const string B);
string findBetrayals(const string input5[], const int N5);
int attack(const string input6[]);
int calculateNoOfWaitingDays(const string input7Str, const string input7Matrix[], const int k);

////////////////////////////////////////////////////////////////////////////
/// STUDENT'S ANSWER HERE
////////////////////////////////////////////////////////////////////////////

string readyForBattle(const string ID[], const int NID, const string input1[], const int N1)
{
    return "You can remove this return";
}
int decode(const string A, const string B)
{
    return -1;
}
string findRoute(const string input3)
{
    return "You can remove this return";
}
string decodeVfunction(const string A, const string B)
{
    return "You can remove this return";
}
string findBetrayals(const string input5[], const int N5)
{
    return "You can remove this return";
}
int attack(const string input6[])
{
    return -1;
}
int calculateNoOfWaitingDays(const string input7Str, const string input7Matrix[], const int k)
{
    return -1;
}

#endif /* MONGOL_H */
